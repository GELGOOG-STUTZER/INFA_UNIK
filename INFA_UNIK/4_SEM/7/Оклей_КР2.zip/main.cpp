#include<stdio.h>
#include "7.h"
#include<vector>
#include<string>
int main() {

}
